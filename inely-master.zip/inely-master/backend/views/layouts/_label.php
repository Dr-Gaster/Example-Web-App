<li data-key="<?= $key ?>">
    <a class="<?= $model->badgeColor ?>" href="#">
        <i class="entypo-tag"></i>
        <span><?= $model->labelName ?></span>
        <i class="entypo-trash rm-label"></i>
    </a>
</li>
