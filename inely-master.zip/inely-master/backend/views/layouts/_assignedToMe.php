<?php if ($this->params['haveAssignedToMe']): ?>

<li>
    <a class="tooltip-tip ajax-load assignedGroup" title="Поручены мне" href="#">
        <i class="entypo-user-add"></i>
        <span>Поручены мне</span>

        <div class="noft-blue-number counter assign"></div>
    </a>
</li>

<?php endif ?>
