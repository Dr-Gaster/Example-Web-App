<?php

namespace common\assets;

class FontAwesome extends \yii\web\AssetBundle
{
    public $sourcePath = '@vendor/fortawesome/font-awesome';
    public $css        = ['css/font-awesome.min.css'];
}