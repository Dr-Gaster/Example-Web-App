<?php

namespace common\assets;

class JuiAsset extends \yii\web\AssetBundle
{
    public $sourcePath = '@bower/jquery-ui';
    public $js         = ['jquery-ui.js'];
}