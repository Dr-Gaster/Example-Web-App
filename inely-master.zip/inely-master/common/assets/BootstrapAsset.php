<?php

namespace common\assets;

class BootstrapAsset extends \yii\bootstrap\BootstrapAsset
{
    public $sourcePath = '@bower/bootstrap/dist';
    public $js         = ['js/bootstrap.min.js'];
}
