<?php

require(Yii::getAlias('@yii/rbac/migrations/m140506_102106_rbac_init.php'));

class m140703_123813_rbac extends m140506_102106_rbac_init
{

}
