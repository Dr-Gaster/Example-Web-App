frontend\assets\ErrorAsset
===============






* Class name: ErrorAsset
* Namespace: frontend\assets
* Parent class: yii\web\AssetBundle





Properties
----------


### $basePath

    public mixed $basePath = '@webroot'





* Visibility: **public**


### $baseUrl

    public mixed $baseUrl = '@web'





* Visibility: **public**


### $css

    public mixed $css = array('css/error.css')





* Visibility: **public**


### $js

    public mixed $js = array('js/404.js')





* Visibility: **public**


### $jsOptions

    public mixed $jsOptions = array('position' => \yii\web\View::POS_HEAD)





* Visibility: **public**


### $depends

    public mixed $depends = array('yii\web\JqueryAsset')





* Visibility: **public**



