frontend\modules\user\Module
===============






* Class name: Module
* Namespace: frontend\modules\user
* Parent class: yii\base\Module





Properties
----------


### $controllerNamespace

    public mixed $controllerNamespace = 'frontend\modules\user\controllers'





* Visibility: **public**


Methods
-------


### init

    mixed frontend\modules\user\Module::init()





* Visibility: **public**



