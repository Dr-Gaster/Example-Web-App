frontend\assets\AuthAsset
===============






* Class name: AuthAsset
* Namespace: frontend\assets
* Parent class: yii\web\AssetBundle





Properties
----------


### $basePath

    public mixed $basePath = '@webroot'





* Visibility: **public**


### $baseUrl

    public mixed $baseUrl = '@web'





* Visibility: **public**


### $css

    public mixed $css = array('https://fonts.googleapis.com/css?family=Open+Sans:300,400&subset=cyrillic', 'css/auth.css', 'fonts/icomoon/icomoon.css', 'fonts/simple-line-icons/simple-line-icons.css')





* Visibility: **public**



