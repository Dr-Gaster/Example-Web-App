frontend\controllers\LandController
===============






* Class name: LandController
* Namespace: frontend\controllers
* Parent class: yii\web\Controller







Methods
-------


### actions

    mixed frontend\controllers\LandController::actions()





* Visibility: **public**




### behaviors

    mixed frontend\controllers\LandController::behaviors()





* Visibility: **public**




### actionIndex

    mixed frontend\controllers\LandController::actionIndex()





* Visibility: **public**




### actionContact

    mixed frontend\controllers\LandController::actionContact()





* Visibility: **public**




### actionError

    mixed frontend\controllers\LandController::actionError()





* Visibility: **public**




### beforeAction

    mixed frontend\controllers\LandController::beforeAction($action)





* Visibility: **public**


#### Arguments
* $action **mixed**


