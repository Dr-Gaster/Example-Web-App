backend\controllers\DocsController
===============

Class DocsController




* Class name: DocsController
* Namespace: backend\controllers
* Parent class: yii\web\Controller





Properties
----------


### $layout

    public mixed $layout = 'support'





* Visibility: **public**


Methods
-------


### actionIndex

    mixed backend\controllers\DocsController::actionIndex()





* Visibility: **public**



