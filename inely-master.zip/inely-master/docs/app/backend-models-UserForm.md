backend\models\UserForm
===============






* Class name: UserForm
* Namespace: backend\models
* Parent class: yii\base\Model





Properties
----------


### $email

    public mixed $email





* Visibility: **public**


Methods
-------


### rules

    mixed backend\models\UserForm::rules()





* Visibility: **public**




### attributeLabels

    mixed backend\models\UserForm::attributeLabels()





* Visibility: **public**



