common\commands\SendEmailCommand
===============






* Class name: SendEmailCommand
* Namespace: common\commands
* Parent class: trntv\tactician\base\BaseCommand





Properties
----------


### $from

    public mixed $from





* Visibility: **public**


### $to

    public mixed $to





* Visibility: **public**


### $subject

    public string $subject





* Visibility: **public**


### $view

    public string $view





* Visibility: **public**


### $params

    public array $params





* Visibility: **public**


### $body

    public string $body





* Visibility: **public**


### $html

    public boolean $html = true





* Visibility: **public**


Methods
-------


### init

    mixed common\commands\SendEmailCommand::init()

Command init



* Visibility: **public**




### isHtml

    boolean common\commands\SendEmailCommand::isHtml()





* Visibility: **public**



