common\commands\SendEmailHandler
===============






* Class name: SendEmailHandler
* Namespace: common\commands
* Parent class: trntv\tactician\base\BaseHandler







Methods
-------


### handle

    boolean common\commands\SendEmailHandler::handle(\common\commands\SendEmailCommand $command)





* Visibility: **public**


#### Arguments
* $command **[common\commands\SendEmailCommand](common-commands-SendEmailCommand.md)**


