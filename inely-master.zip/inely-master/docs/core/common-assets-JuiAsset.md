common\assets\JuiAsset
===============






* Class name: JuiAsset
* Namespace: common\assets
* Parent class: yii\web\AssetBundle





Properties
----------


### $sourcePath

    public mixed $sourcePath = '@bower/jquery-ui'





* Visibility: **public**


### $js

    public mixed $js = array('jquery-ui.js')





* Visibility: **public**



