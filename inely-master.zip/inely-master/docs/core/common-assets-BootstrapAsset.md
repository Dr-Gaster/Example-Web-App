common\assets\BootstrapAsset
===============






* Class name: BootstrapAsset
* Namespace: common\assets
* Parent class: yii\bootstrap\BootstrapAsset





Properties
----------


### $sourcePath

    public mixed $sourcePath = '@bower/bootstrap/dist'





* Visibility: **public**


### $js

    public mixed $js = array('js/bootstrap.min.js')





* Visibility: **public**



