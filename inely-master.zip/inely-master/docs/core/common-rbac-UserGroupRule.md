common\rbac\UserGroupRule
===============

Checks if authorID matches user passed via params




* Class name: UserGroupRule
* Namespace: common\rbac
* Parent class: yii\rbac\Rule





Properties
----------


### $name

    public mixed $name = 'userGroup'





* Visibility: **public**


Methods
-------


### execute

    mixed common\rbac\UserGroupRule::execute($user, $item, $params)





* Visibility: **public**


#### Arguments
* $user **mixed**
* $item **mixed**
* $params **mixed**


