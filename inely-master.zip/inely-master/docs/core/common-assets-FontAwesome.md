common\assets\FontAwesome
===============






* Class name: FontAwesome
* Namespace: common\assets
* Parent class: yii\web\AssetBundle





Properties
----------


### $sourcePath

    public mixed $sourcePath = '@vendor/fortawesome/font-awesome'





* Visibility: **public**


### $css

    public mixed $css = array('css/font-awesome.min.css')





* Visibility: **public**



