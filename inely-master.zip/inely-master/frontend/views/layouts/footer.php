<footer class="copyright-terms">
    <div class="container">
        <div class="row">
            <div class="col-sm-5 col-md-6">
                <small> &copy; 2016 Vlasenko. All rights reserved.</small>
            </div>
            <div class="col-sm-7 col-md-6">
                <ul class="terms-privacy">
                    <li><a href="" data-toggle="modal" data-target="#modal-terms">Политика приватности</a></li>
                    <li><a href="" data-toggle="modal" data-target="#modal-terms">Cookies</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>